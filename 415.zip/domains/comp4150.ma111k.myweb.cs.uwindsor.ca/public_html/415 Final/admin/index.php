

<?php require_once "../config/adminLogin.php";?>
<?php require_once "header.php"?>
<?php require_once "../config/database.php"?>

<style>
	.panel-body{
		text-align:center;
		font-size:30px;
		font-weight:bold
	}
	.panel-title img{
		width:20px;
		float:right
	}
</style>
<!-- panel -->
<div class="cm-right" style=''>
	
    <div class="block01" style='width:100%;padding-top:20px;padding-right:60px;'>
        <h3>Home</h3>
        <div class="container">
		<div class="container">
   <div class="jumbotron">
        <h1>Welcome !</h1>
        <p>You can manage your books and orders !</p>
        <p><a href="./book.php" class="btn btn-primary btn-lg" role="button">
        My book</a>
      </p>
   </div>
</div>
		</div>	

		
</div>

		
	
	
	

    </div>
    <div style="height: 65px;"></div>
</div>
	<!-- panel -->			
				
<?php require_once "footer.php"?>	
 

 
				

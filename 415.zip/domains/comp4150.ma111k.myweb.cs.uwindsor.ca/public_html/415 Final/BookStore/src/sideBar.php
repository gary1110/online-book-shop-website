<div class="sidebar-heading">Category </div>
      <div class="list-group list-group-flush">
      
                      

        <a href="./books.php?tag=Drama&name=&author=" class="list-group-item list-group-item-action bg-light" >Drama</a>
        <a href="./books.php?tag=Inspiration&name=&author=" class="list-group-item list-group-item-action bg-light" >Inspiration</a>
        <a href="./books.php?tag=Love Story&name=&author=" class="list-group-item list-group-item-action bg-light" >Love Story</a>
        <a href="./books.php?tag=Life Style&name=&author=" class="list-group-item list-group-item-action bg-light" >Life Style</a>
        <a href="./books.php?tag=Business&name=&author=" class="list-group-item list-group-item-action bg-light" >Business</a>
        <a href="./books.php?tag=Culture&name=&author=" class="list-group-item list-group-item-action bg-light" >Culture</a>
        <a href="./books.php?tag=Science&name=&author=" class="list-group-item list-group-item-action bg-light" >Science</a>
      </div>